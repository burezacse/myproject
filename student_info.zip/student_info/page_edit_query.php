<?php 
include 'connect.php';
if(isset($_POST['submit'])) 
 {

	$id 		 = $_POST['id'];
	$page		 = $_POST['page_name'];
	$description = $_POST['description'];
	$status		 = $_POST['status'];
	$fileName    = $_FILES['image']['name'];
	$filesize    = $_FILES['image']['size'];	
	$target_dir  = "images/";
    $path        = $target_dir.$fileName;
    if ($filesize > 0) {
    	$sql     = "SELECT * FROM page WHERE id = $id";
		$result  = mysqli_query($conn, $sql);
		$row     = mysqli_fetch_assoc($result);
		@unlink($target_dir.$row['image']);
		move_uploaded_file($_FILES['image']['tmp_name'],$path);
		$update  ="UPDATE page SET page_name='$page', description='$description' image= '$fileName', status='$status' WHERE id = $id";
 		$result2 = mysqli_query($conn, $update);
 		 
    }else{
    	$update1  ="UPDATE page SET page_name='$page', description='$description', status='$status' WHERE id = $id";
 		$result3 = mysqli_query($conn, $update1);
    }
/*echo "<pre>";
print_r($update);
exit();*/
    header('location:page.php'); 
$conn->close();
}
 ?>