<?php 
include 'connect.php';
if(isset($_POST['submit'])) 
 {

	$id 		 = $_POST['id'];
	$name		 = $_POST['name'];
	$status		 = $_POST['status'];
    	$sql     = "SELECT * FROM menu WHERE id = $id";
		$result  = mysqli_query($conn, $sql);
		$update  ="UPDATE menu SET name='$name', status='$status' WHERE id = $id";
 		$result2 = mysqli_query($conn, $update);
 		 
    
/*echo "<pre>";
print_r($update);
exit();*/
    header('location:menu.php'); 
$conn->close();
}
 ?>