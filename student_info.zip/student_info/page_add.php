<?php include'common/header.php';?>
<?php
    include'connect.php';
    $sql    = "SELECT * FROM menu";
    $result = $conn->query($sql);
    //echo "<pre>";
    //print_r($row);exit();
?>
<div id="wrapper">
    <?php include"common/navbar.php";?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">New Page</h1>
                </div>
            </div>
            <div class="row">
                <div class="panel-body">
                    <div style="max-width: 600px; margin:0 auto;">
                        <form name="myForm" action="page_insert.php" method="POST" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="name">Page Name</label>
                                <input type="text" name="name" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="">Select Menu</label>
                                <select class="form-control" name="menu_id" style="width:;">
                                    <option value="">--Please Select--</option>
                                    <?php foreach($result as $row){?>
                                        <option value="<?php echo $row['id']?>"><?php echo $row['name']?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="description">Description</label>
                                <textarea name="description" rows="2" class="form-control" id="description" required="required"></textarea>
                            </div>
                            <div class="form-group">
                                <label for="image">Image</label>
                                <input type="file" name="image" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="status">Status</label>
                                <select class="form-control" name="status">
                                    <option value="Active">Active</option>
                                    <option value="Inactive">Inactive</option>
                                </select>
                            </div>
                            
                            <button type="submit" name="button" class="btn btn-success">Submit</button> 
                        </form>
                    </div>
                </div>
            </div>
        </div>
</div>

<?php include'common/footer.php'; ?>