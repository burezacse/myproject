<?php
	include 'connect.php';
	$id     = $_GET['id'];
	$delete = "DELETE FROM menu WHERE id=$id";
	$result	= $conn->query($delete);
header('location:menu.php');

/*echo "<pre>";
print_r($);
	echo "<pre>";
*/
?>