<?php include'common/header.php';?>
<div id="wrapper">
    <?php include"common/navbar.php";?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-sm-8">
                    <h1 class="">Users</h1>
                </div>
                <div class="col-sm-4">
                <br>
                    <a href="new_user.php" class="btn btn-primary pull-right">Add User</a>
                </div>
            </div><hr>

            <div class="row">
                <?php
                    include"list.php";
                ?>
            </div>
            
        </div>
</div>
<?php include'common/footer.php'; ?>