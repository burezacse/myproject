<?php include'common/header.php';?>
<div id="wrapper">
    <?php include"common/navbar.php";?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Update User</h1>
                </div>
            </div>
<?php 
	include "connect.php";

	$std_id	= $_GET['id'];
	$sql	= "SELECT s.* , d.* FROM student s join student_details d on s.id=d.student_id where s.id=$std_id";
	$result = $conn->query($sql);
	$row 	= mysqli_fetch_row($result);
	
		//echo "<pre>";
		//print_r($row);exit();

	?>

            <div class="row">
            	<div class="panel-body">
					<div style="max-width: 600px; margin:0 auto;">
						<form name="myForm" action="" method="POST" >
							<div class="form-group">
							<input type="hidden" name="id" id="id" value="<?php echo $row[0]; ?>">
								<label for="name">Name</label>
								<input type="text" name="name" id="name" value="<?php echo $row[1]; ?>" class="form-control">
							</div>
							<div class="form-group">
			      				<label for="age">Age</label>  
			      				<input type="text" name="age" id="age" value="<?php echo $row[6]; ?>" class="form-control" >
			    			</div>
			    			<div class="form-group">
			      				<label for="thana">Thana</label>  
			      				<input type="text" name="thana" value="<?php echo $row[7]; ?>" class="form-control" >
			    			</div>
			    			<div class="form-group">
			      				<label for="district">District</label>  
			      				<input type="text" name="district" value="<?php echo $row[8]; ?>" class="form-control" >
			    			</div>
			    			
							<button type="update" name="update" class="btn btn-success" >Update</button> 
						</form>
					</div>
				</div>
        	</div>
        </div>
</div>
<?php include'common/footer.php'; ?>

<?php
	if(isset($_POST['update'])){
		$id 		= $_POST['id'];
		$name 		= $_POST['name'];
		$age 		= $_POST['age'];
		$thana 		= $_POST['thana'];
		$district  	= $_POST['district'];

		$sql="UPDATE student SET name='$name' WHERE id=$id";
		$result		= $conn->query($sql);
		//echo $result;
		$sql2="UPDATE student_details SET age='$age', thana='$thana', district='$district' WHERE student_id=$id";
		$result		= $conn->query($sql2);
		

		$conn->close();
    }
?>

