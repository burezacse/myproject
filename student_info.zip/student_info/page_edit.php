<?php include'common/header.php';?>
<div id="wrapper">
    <?php include"common/navbar.php";?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Edit Page</h1>
                </div>
            </div>
           <?php
    include'connect.php';

    $id=$_GET['id'];
    $sql="SELECT * FROM page WHERE id=$id";
        $result=$conn->query($sql);
        $row=mysqli_fetch_row($result);
        //echo "<pre>";
        //print_r($row);
     ?>
            <form method="post" action="page_edit_query.php" enctype="multipart/form-data">

                    <table align="center" width="750">

                        <tr align="center">
                            <td colspan="6"><h2>Update Your Page</h2></td>
                        </tr>
                        <tr>
                            
                            <td><input type="hidden" name="id" value="<?php echo $row[0];?>" /></td>
                        </tr>
                        <tr>
                            
                            <td><input type="hidden" name="menu_id" value="<?php echo $row[1];?>" /></td>
                        </tr>
                       
                        <tr>
                            <td align="right">Page Name:</td>
                            <td><input type="text" name="page_name" value="<?php echo $row[2];?>" ></td>
                        </tr>
                        <tr>
                            <td align="right">Description:</td>
                            <td><input type="text" name="description" value="<?php echo $row[3];?>" ></td>
                        </tr>

                        <tr>
                            <td align="right">Image:</td>
                            <td><input type="file" name="image" value="<?php echo $row[4];?>" /></td>
                        </tr>

                        <tr>
                            <td align="right">Status:</td>
                            <td>
                            <select name="status" value="<?php echo $row[5];?>">
                                <option>Select a Status</option>
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                                
                            </select>

                            </td>
                        </tr> 

                    <tr align="center">
                        <td colspan="6"><input type="submit" name="submit" value="Create Banner" /></td>
                    </tr>

                    </table>

                </form>
        </div>
</div>

<?php include'common/footer.php'; ?>