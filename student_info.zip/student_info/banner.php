<?php 
    include'common/header.php';
    
    ?>

<div id="wrapper">
    <?php include"common/navbar.php";?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-sm-9">
                    <h1>Banner</h1>
                </div>
                <div class="col-sm-3">
                <br>
                    <a href="banner_add.php" class="btn btn-primary pull-right">Add Banner</a>
                </div>
            </div>
            <div class="row">
<?php
	include'connect.php';
	$sql	= "SELECT * FROM banner";
	$result = $conn->query($sql);
?>	
<table class="table table-bordered">
	<tr>
		 <th width="05%">Serial</th>
		 <th width="15%">Title</th>
		 <th width="15%">Image</th>
		 <th width="05%">Status</th>
		 <th width="10%">Action</th>
	</tr>
	<?php
		while($row=$result->fetch_assoc()){
	?>
	<tr>
		 <td><?php echo $row["id"]?></td>
		 <td><?php echo $row["title"]?></td>
		 <td><img height="100px" width="100px" src="images/<?php echo $row['image']?>"></td>
		 <td><?php echo $row["status"]?></td>
		 <td>
		 	<a href="banner_edit.php?id=<?php echo $row["id"]?>">Edit</a>
		 	<a href="banner_delete.php?id=<?php echo $row["id"]?>">Delete</a>
		 </td>
	</tr>
	<?php
		
		}
	?>
</table>
            </div>
        </div>
</div>

<?php include'common/footer.php'; ?>