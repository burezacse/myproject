<?php
	include'connect.php';
	$sql    = "SELECT s.* , d.student_id,d.age,d.thana,d.district FROM student s join student_details d on s.id=d.student_id";
	//echo $sql;exit();
	$result = $conn->query($sql);
?>	
<table class="table table-bordered">
	<tr>
		 <th width="05%">Serial</th>
		 <th width="15%">Name</th>
		 <th width="15%">E-mail</th>
		 <th width="05%">Age</th>
		 <th width="15%">Thana</th>
		 <th width="15%">District</th>
		 <th width="20%">Action</th>
	</tr>
	<?php
		while($row=$result->fetch_assoc()){
	?>
	<tr>
		 <td><?php echo $row["id"]?></td>
		 <td><?php echo $row["name"]?></td>
		 <td><?php echo $row["email"]?></td>
		 <td><?php echo $row["age"]?></td>
		 <td><?php echo $row["thana"]?></td>
		 <td><?php echo $row["district"]?></td>

		 <td>
		 	<a href="view.php?id=<?php echo $row["id"]?>">View</a>
		 	<a href="update.php?id=<?php echo $row["id"]?>">Update</a>
		 	<a href="delete.php?id=<?php echo $row["id"]?>" onClick="return confirm('Are you sure delete user?')" >Delete</a>
		 </td>
	</tr>
	<?php
		
		}
	?>
</table>