<?php
	include"connect.php";
?>
<?php

	$delete		= $_GET['id'];
	$sql		= "DELETE FROM student WHERE id=$delete";
	$result		= $conn->query($sql);
	$sql2		= "DELETE FROM student_details WHERE student_id=$delete";
	$result		= $conn->query($sql2);
header("location:users.php");
?>
