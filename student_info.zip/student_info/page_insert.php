<?php 
include 'connect.php';

if(isset($_POST['button']))
{   
        $target_dir  = "images/";
        $menu_id     = $_POST['menu_id'];
        $page_name   = $_POST['name'];
        $description = $_POST['description'];
        $status      = $_POST['status'];
        $fileName    = time().$_FILES['image']['name'];
        $path        = $target_dir.$fileName;
        move_uploaded_file($_FILES['image']['tmp_name'],$path);
        $sql = "INSERT INTO page(menu_id,page_name,description,image,status) VALUES( $menu_id, '$page_name', '$description', '$fileName', '$status')";
        $conn->query($sql);
        //echo "<pre>";
   //print_r($conn);exit();
        header('location:page.php');  
     }
  
?>