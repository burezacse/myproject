<?php include'common/header.php';?>

<div id="wrapper">
    <?php include"common/navbar.php";?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-sm-9">
                    <h2>Page List</h2>
                </div>
                <div class="col-sm-3">
                <br>
                    <a href="page_add.php" class="btn btn-primary pull-right">Add New Page</a>
                </div>
            </div>
            <div class="row">
<?php
    include'connect.php';
   
    $sql    = "SELECT p.* , m.name FROM page p left join menu m on p.id=m.id";
    $result = $conn->query($sql);

    //echo "<pre>";
   // print_r($sql);exit();
?>  
<table class="table table-bordered">
    <tr>
         <th width="5%">Serial No:</th>
         <th width="10%">Page Name</th>
         <th width="10%">Menu Name</th>
         <th width="10%">Description</th>
         <th width="10%">image</th>
         <th width="10%">Status</th>
         <th width="10%">Action</th>
    </tr>
    <?php
        while($row=$result->fetch_assoc()){
    ?>
    <tr>
         <td><?php echo $row["id"]?></td>
         <td><?php echo $row["page_name"]?></td>
         <td><?php echo $row["name"]?></td>
         <td><?php echo $row["description"]?></td>
         <td><img height="100px" width="100px" src="images/<?php echo $row['image']?>"></td>
         <td><?php echo $row["status"]?></td>
         <td>
            <a href="page_edit.php?id=<?php echo $row["id"]?>">Edit</a>
            <a href="page_delete.php?id=<?php echo $row["id"]?>">Delete</a>
         </td>
    </tr>
    <?php
        
        }
    ?>
</table>
            </div>
        </div>
</div>

<?php include'common/footer.php'; ?>