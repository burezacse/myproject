<?php include'common/header.php';?>

<div id="wrapper">
    <div class="panel-body">
		<div style="max-width: 400px; margin:0 auto;">
			<form name="myForm" action="#" onsubmit="return validateForm()" method="post" enctype="multipart/form-data">
				<div class="form-group">
					<label for="email">Email Address</label>
					<input type="text" id="email" name="email" class="form-control" >
				</div>
				<div class="form-group">
					<label for="login">Login</label>
					<input type="login" name="login" class="form-control">
				</div>
				<button type="submit" class="btn btn-success pull-center">Login</button> 
			</form>
		</div>
	</div>
</div>

<?php include'common/footer.php'; ?>







