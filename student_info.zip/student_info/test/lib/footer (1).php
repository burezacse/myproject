<?php
	include 'lib/content.php';
?>
</html>