<?php include"connect.php" ?>

<?php
	$name		= $_POST['name'];
	$email		= $_POST['email'];
	$pass		= $_POST['password'];
	$age		= $_POST['age'];
	$thana		= $_POST['thana'];
	$district	= $_POST['district'];

	$sql   		= "INSERT INTO student(name,email,password) VALUES ('$name', '$email', '$pass') INSERT INTO student_details(age,thana,district) VALUES('$age', '$thana' '$')";
	$conn->query($sql);
	header("location:users.php");
	$conn->close();

?>