<?php include'common/header.php';?>

<div id="wrapper">
    <?php include"common/navbar.php";?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-sm-9">
                    <h1>Menu</h1>
                </div>
                <div class="col-sm-3">
                <br>
                    <a href="menu_add.php" class="btn btn-primary pull-right">Add Menu</a>
                </div>
            </div>
            <div class="row">
<?php
    include'connect.php';
    $sql    = "SELECT * FROM menu";
    $result = $conn->query($sql);
?>  
<table class="table table-bordered">
    <tr>
         
         <th width="10%">Name</th>
         <th width="10%">Status</th>
         <th width="10%">Action</th>
    </tr>
    <?php
        while($row=$result->fetch_assoc()){
    ?>
    <tr>
         
         <td><?php echo $row["name"]?></td>
         <td><?php echo $row["status"]?></td>
         <td>
            <a href="menu_edit.php?id=<?php echo $row["id"]?>">Edit</a>
            <a href="menu_delete.php?id=<?php echo $row["id"]?>">Delete</a>
         </td>
    </tr>
    <?php
        
        }
    ?>
</table>
            </div>
        </div>
</div>

<?php include'common/footer.php'; ?>