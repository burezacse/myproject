<?php include'common/header.php';?>
<div id="wrapper">
    <?php include"common/navbar.php";?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">New User</h1>
                </div>
            </div>
            <div class="row">
            	<div class="panel-body">
					<div style="max-width: 600px; margin:0 auto;">
						<form name="myForm" action="" method="post" >
							<div class="form-group">
								<label for="name">Name</label>
								<input type="text" name="name" class="form-control">
							</div>
							<div class="form-group">
								<label for="email">Email Address</label>
								<input type="text" name="email" class="form-control" >
							</div>
							<div class="form-group">
								<label for="password">Password</label>
								<input type="password" name="password" class="form-control">
							</div>
							<div class="form-group">
			      				<label for="age">Age</label>  
			      				<input type="text" name="age" class="form-control" >
			    			</div>
			    			<div class="form-group">
			      				<label for="thana">Thana</label>  
			      				<input type="text" name="thana" class="form-control" >
			    			</div>
			    			<div class="form-group">
			      				<label for="district">District</label>  
			      				<input type="text" name="district" class="form-control" >
			    			</div>
			    			
							<button type="submit" name="button" class="btn btn-success">Submit</button> 
						</form>
					</div>
				</div>
        	</div>
        </div>
</div>

<?php include'common/footer.php'; ?>

<?php
include 'connect.php';

	if (isset($_POST['button'])) {
	$name		= $_POST['name'];
	$email		= $_POST['email'];
	$pass		= hash("md5", $_POST['password']);
	$age		= $_POST['age'];
	$thana		= $_POST['thana'];
	$district	= $_POST['district'];

	$sql   		= "INSERT INTO student(name,email,password) VALUES ('$name', '$email', '$pass')";
	$conn->query($sql);
	$last_id 	= $conn->insert_id;
	$sql   		= "INSERT INTO student_details(student_id,age,thana,district) VALUES ('$last_id', '$age', '$thana', '$district')";
	$conn->query($sql);

	$conn->close();
	
	}
?>