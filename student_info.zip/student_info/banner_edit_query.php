<?php 
include 'connect.php';
if(isset($_POST['submit'])) 
 {

	$id 		 = $_POST['id'];
	$title		 = $_POST['title'];
	$status		 = $_POST['status'];
	$fileName    = $_FILES['image']['name'];
	$filesize    = $_FILES['image']['size'];	
	$target_dir  = "images/";
    $path        = $target_dir.$fileName;
    if ($filesize > 0) {
    	$sql     = "SELECT * FROM banner WHERE id = $id";
		$result  = mysqli_query($conn, $sql);
		$row     = mysqli_fetch_assoc($result);
		@unlink($target_dir.$row['image']);
		move_uploaded_file($_FILES['image']['tmp_name'],$path);
		$update  ="UPDATE banner SET title='$title', image= '$fileName', status='$status' WHERE id = $id";
 		$result2 = mysqli_query($conn, $update);
 		 
    }else{
    	$update  ="UPDATE banner SET title='$title', status='$status' WHERE id = $id";
 		$result2 = mysqli_query($conn, $update);
    }
/*echo "<pre>";
print_r($update);
exit();*/
    header('location:banner.php'); 
$conn->close();
}
 ?>