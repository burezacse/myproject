<?php 
include 'connect.php';
if(isset($_POST['submit']))
{   
        $name       = $_POST['name'];
        $status     = $_POST['status'];
        $sql        = "INSERT INTO menu (name,status) VALUES( '$name', '$status')";
        $conn->query($sql);
       // $last_id 	= $conn->insert_id;
        //echo "<pre>";
        //print_r($last_id);exit();
         header('location:menu.php');  
     }
?>