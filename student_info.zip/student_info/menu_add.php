<?php include'common/header.php';?>
<div id="wrapper">
    <?php include"common/navbar.php";?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">New Menu</h1>
                </div>
            </div>
            <form method="post" action="menu_insert.php" enctype="multipart/form-data">
                    <table align="center" width="750">
                        <tr>
                            <td align="right">Name:</td>
                            <td><input type="text" name="name" /></td>
                        </tr>
                        <tr>
                            <td align="right">Status:</td>
                            <td>
                            <select name="status">
                                <option>Select a Status</option>
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                            </td>
                        </tr> 
                    <tr align="center">
                        <td colspan="6"><input type="submit" name="submit" value="Create Menu" /></td>
                    </tr>
                    </table>
                </form>
        </div>
</div>
<?php include'common/footer.php'; ?>