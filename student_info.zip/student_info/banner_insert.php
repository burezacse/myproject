<?php 
include 'connect.php';

if(isset($_POST['submit']))
{   
        $target_dir  = "images/";
        $title       = $_POST['title'];
        $status      = $_POST['status'];
        $fileName    = time().$_FILES['image']['name'];
        $path        = $target_dir.$fileName;
        move_uploaded_file($_FILES['image']['tmp_name'],$path);

         $sql = "INSERT INTO banner(title,image,status) VALUES( '$title', '$fileName', '$status')";
         $conn->query($sql);
         header('location:banner.php');  
     }
  
?>