<?php
	include 'connect.php';
	$folder = "images/";
	$id     = $_GET['id'];
$sql        = "SELECT * FROM banner WHERE id = $id";
$result 	= mysqli_query($conn, $sql);
$row        = mysqli_fetch_assoc($result);
@unlink($folder.$row['image']);
$delete = "DELETE FROM banner WHERE id=$id";
$result		= $conn->query($delete);

header('location:banner.php');

/*echo "<pre>";
print_r($row);
	echo "<pre>";
*/
?>