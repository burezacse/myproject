<?php 
    include'common/header.php';
    session_start();
    if ($_SESSION['name']==NULL) {
        header("location: admin/index.php");
    }
    ?>

<div id="wrapper">
    <?php include"common/navbar.php";?>
        <div id="page-wrapper">
            <div class="row">
                
            </div>
            <div class="row">
                <?php
                    include"list.php";
                ?>
            </div>
        </div>
</div>

<?php include'common/footer.php'; ?>