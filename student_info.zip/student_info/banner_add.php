<?php include'common/header.php';?>
<div id="wrapper">
    <?php include"common/navbar.php";?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">New Banner</h1>
                </div>
            </div>
           
            <form method="post" action="banner_insert.php" enctype="multipart/form-data">

                    <table align="center" width="750">

                        <tr align="center">
                            <td colspan="6"><h2>Create an Title</h2></td>
                        </tr>

                       
                        <tr>
                            <td align="right">Title:</td>
                            <td><input type="text" name="title" required/></td>
                        </tr>

                        <tr>
                            <td align="right">Image:</td>
                            <td><input type="file" name="image" /></td>
                        </tr>

                        <tr>
                            <td align="right">Status:</td>
                            <td>
                            <select name="status">
                                <option>Select a Status</option>
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                                
                            </select>

                            </td>
                        </tr> 

                    <tr align="center">
                        <td colspan="6"><input type="submit" name="submit" value="Create Banner" /></td>
                    </tr>

                    </table>

                </form>
        </div>
</div>

<?php include'common/footer.php'; ?>