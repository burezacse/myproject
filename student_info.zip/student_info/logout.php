<?php 
    include'common/header.php';
    session_start();
    if ($_SESSION['name']==NULL) {
        header("location: admin/index.php");
    }
    ?>

<div id="wrapper">
    <?php include"common/navbar.php";?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    
                    
                </div>
            </div>
            
        </div>
</div>

<?php include'common/footer.php'; ?>