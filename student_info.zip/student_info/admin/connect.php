<?php
	$host 	= 'localhost';
	$user 	= 'root';
	$pass	= '';
	$db		= 'student_info';
	$conn = new mysqli($host,$user,$pass,$db) or die($mysqli->error);
	
?>