<?php include'../common/header.php';?>

<div id="wrapper">
    <?php include"../common/navbar.php";?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Home</h1>
                </div>
            </div>
            <div class="row">
                
            </div>
        </div>
</div>

<?php include'../common/footer.php'; ?>