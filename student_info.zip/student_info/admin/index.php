<?php
   include("connect.php");
   include'../common/header.php';
   session_start();
   
   if(isset($_POST["button"])) {

      $myusername = $_POST['email'];
      $mypassword = $_POST['password'];
      
      $sql        = "SELECT * FROM tbl_admin WHERE email = '$myusername' and password = '$mypassword'";
      $result = mysqli_query($conn, $sql);
      $cnt    = mysqli_num_rows($result);
      //echo $count;exit();
      if($cnt>0) {
        $row                = mysqli_fetch_assoc($result);
        $_SESSION['name']   = $row['name'];
        $_SESSION['id']     = $row['id'];

         header("location: ../index.php");
      }else {
         $message = "Your Login Name or Password is invalid";
      }
      exit();
   }
  
?>
<html>
   
   <head>
      <title>Login Page</title>
   </head>
<body>
      <div id="wrapper">
         <div class="panel-body" style="max-width: 600px; margin:0 auto;">
            <div class="row" >
                <div class="col-lg-12">
                    <h1 class="page-header">Login Page</h1>
                </div>
            </div>
            <div class="row">
                <form action="" method="POST">
                        <fieldset>
                            <div class="form-group">
                                <input class="form-control" placeholder="E-mail" name="email" type="text" >
                            </div>
                            <div class="form-group">
                                <input class="form-control" placeholder="Password" name="password" type="password" value="">
                            </div>
                                <button type="submit" name="button" class="btn btn-success">Login</button>
                        </fieldset>
                </form>
            </div>
        </div>
    </div>
</body>
</html>