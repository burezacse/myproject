<?php
   include'connect.php';
   session_start();
   //echo "<pre>";print_r($_SESSION['result']['id']);exit();
   $user_check = $_SESSION['result'];   
   if(!isset($user_check)){
      header("location:login.php");
   }else{
   	 header("location:index.php");
   }
?>